package Test;

import DAO.KhachHangDAO;
import model.KhachHang;

public class TestDatabase {
    public static void main(String[] args) {
    }
}
